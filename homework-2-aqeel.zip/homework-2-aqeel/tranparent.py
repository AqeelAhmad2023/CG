import numpy as np
from PIL import Image, ImageDraw
import math
from math import sqrt

WIDTH, HEIGHT = 400, 400
IMAGE_SIZE = 3 * WIDTH * HEIGHT
image = list(np.zeros(IMAGE_SIZE))

#triangle and its vertices.

vertices = [[60.5, 175.5], [224.5, 325.5], [374.5, 190.5],
           [74.5, 285.5], [350.5, 300.5], [150., 100.],
           [25., 125.], [0., 0.]]
triangles = [[0, 1, 2], [0, 3, 1], [1, 4, 2], [0, 2, 5], [0, 3, 6]]
gamma_correction=0

def set_pixel_alpha(x, y, r, g, b, a):
    index = None
    transparency = 1 - a
    transp = (1 - a) / 255.
    if 0 <= x < WIDTH and 0 <= y < HEIGHT:
        index = 3 * (x + WIDTH * y)
        if gamma_correction:
            image[index] = int(255 * sqrt(a * r + transp * float(image[index])))
            image[index + 1] = int(255 * sqrt(a * g + transp * float(image[index + 1])))
            image[index + 2] = int(255 * sqrt(a * b + transp * float(image[index + 2])))
        else:
            image[index] = int(255 * a * r + transparency * float(image[index]))
            image[index + 1] = int(255 * a * g + transparency * float(image[index + 1]))
            image[index + 2] = int(255 * a * b + transparency * float(image[index + 2]))

def draw_triangle(x1, y1, x2, y2, x3, y3):
    top_vertical = max(y1, y2, y3)
    bottom_vertical = min(y1, y2, y3)

    m_left = (y2 - y1) / (x2 - x1)
    m_right = (y3 - y2) / (x3 - x2)

    b_left = y2 - x2 * m_left
    b_right = y2 - x2 * m_right

    for y in range(math.floor(top_vertical), math.floor(bottom_vertical), -1):
        if x2 == x1:
            x_left = x2
        else:
            x_left = (y - b_left) / m_left

        if x3 == x2:
            x_right = x3
        else:
            x_right = (y - b_right) / m_right

        for x in range(math.floor(x_left), math.floor(x_right)):
            set_pixel_alpha(math.floor(x), math.floor(y), 0, 0, 1, 1)
Tranparency=128
alpha=0.5
def draw_triangles(img, vertices, triangle, fill):
    x = [vertices[triangle[0]][0], vertices[triangle[1]][0], vertices[triangle[2]][0]]
    y = [vertices[triangle[0]][1], vertices[triangle[1]][1], vertices[triangle[2]][1]]
    create = ImageDraw.Draw(img)
    create.polygon(list(zip(x, y)), fill=fill)


# Create the semi-transparent image
imge_semi = Image.new('RGBA', (500, 500), (0, 0, 0, 255))
imge_semi.putalpha(int(alpha*255+alpha))

for triangle in triangles:
    draw_triangles(imge_semi, vertices, triangle, fill=(0, 0, Tranparency, 0))

imge_semi.save('semitransparent-triangles.bmp')
