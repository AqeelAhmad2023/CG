import numpy as np
from PIL import Image, ImageDraw
import math

WIDTH, HEIGHT = 400, 400
IMAGE_SIZE = 3 * WIDTH * HEIGHT
image = list(np.zeros(IMAGE_SIZE))

#triangle and its vertices.

vertices = [[60.5, 175.5], [224.5, 325.5], [374.5, 190.5],
           [74.5, 285.5], [350.5, 300.5], [150., 100.],
           [25., 125.], [0., 0.]]
triangles = [[0, 1, 2], [0, 3, 1], [1, 4, 2], [0, 2, 5], [0, 3, 6]]

def set_pixel_alpha(img, x, y, alpha, r, g, b, a):
    if x in range(WIDTH) and y in range(HEIGHT):
        index = 3 * (x + WIDTH * y)
        transp = (1 - a) / 255
        image[index] = 255 * ((a * r) ** 0.5 + transp * image[index])
        image[index + 1] = 255 * ((a * g) ** 0.5 + transp * image[index + 1])
        image[index + 2] = 255 * ((a * b) ** 0.5 + transp * image[index + 2])
    img[y, x, 3] = alpha

def draw_triangle(x1, y1, x2, y2, x3, y3):
    top_vertical = max(y1, y2, y3)
    bottom_vertical = min(y1, y2, y3)

    m_left = (y2 - y1) / (x2 - x1)
    m_right = (y3 - y2) / (x3 - x2)

    b_left = y2 - x2 * m_left
    b_right = y2 - x2 * m_right

    for y in range(math.floor(top_vertical), math.floor(bottom_vertical), -1):
        if x2 == x1:
            x_left = x2
        else:
            x_left = (y - b_left) / m_left

        if x3 == x2:
            x_right = x3
        else:
            x_right = (y - b_right) / m_right

        for x in range(math.floor(x_left), math.floor(x_right)):
            set_pixel_alpha(math.floor(x), math.floor(y), 0, 0, 1, 1)

def draw_triangles(img, vertices, triangle, fill):
    x = [vertices[triangle[0]][0], vertices[triangle[1]][0], vertices[triangle[2]][0]]
    y = [vertices[triangle[0]][1], vertices[triangle[1]][1], vertices[triangle[2]][1]]
    create = ImageDraw.Draw(img)
    create.polygon(list(zip(x, y)), fill=fill)


# Create the opaque image
imge_opaque = Image.new('RGBA', (500, 500), (0, 0, 0, 255))

for triangle in triangles:
    draw_triangles(imge_opaque, vertices, triangle, fill=(0, 0, 255, 255))

imge_opaque.save('opaque-triangles.bmp')


