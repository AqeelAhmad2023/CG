from math import floor, sin, cos, pi
import numpy as np
from PIL import Image

WIDTH = 400
HEIGHT = 400
IMAGE_SIZE = 3 * WIDTH * HEIGHT

image = list(np.zeros(IMAGE_SIZE))


# -----_____----- Functions -----_____-----

def set_pixel(x, y, r, g, b):
    if ((x >= 0) and (x < WIDTH) and (y >= 0) and (y < HEIGHT)):
        index = 3 * (x + WIDTH * y)
        image[index] = r
        image[index + 1] = g
        image[index + 2] = b


def draw_line_x1(x1, y1, x2, y2):
    slope = (y2 - y1) / (x2 - x1)

    xstart = floor(x1)
    xstop = floor(x2)
    y = y1 + (xstart + 0.5 - x1) * slope

    for x in range(xstart, xstop):
        iy = floor(y)
        set_pixel(x, iy, 255, 255, 255)

        y += slope

def draw_line_x2(x1, y1, x2, y2):
    slope = (y2 - y1) / (x2 - x1)

    xstart = floor(x1)
    xstop = floor(x2)
    y = y1 + (xstart + 0.5 - x1) * slope

    for x in range(xstart, xstop,-1):
        iy = floor(y)
        set_pixel(x, iy, 255, 255, 255)

        y -= slope


def draw_line_y1(x1, y1, x2, y2):
    slope = (x2 - x1) / (y2 - y1)

    ystart = floor(y1)
    ystop = floor(y2)
    x = x1 + (ystart + 0.5 - y1) * slope

    for y in range(ystart, ystop):
        ix = floor(x)
        set_pixel(ix, y, 255, 255, 255)

        x += slope
def draw_line_y2(x1, y1, x2, y2):
    slope = (x2 - x1) / (y2 - y1)

    ystart = floor(y1)
    ystop = floor(y2)
    x = x1 + (ystart + 0.5 - y1) * slope

    for y in range(ystart, ystop,-1):
        ix = floor(x)
        set_pixel(ix, y, 255, 255, 255)

        x -= slope

def draw_line(x1, y1, x2, y2):
    if abs(x2 - x1) > abs(y2 - y1):
        if x2 > x1:
            draw_line_x1(x1, y1, x2, y2)
        else:
            draw_line_x2(x1, y1, x2, y2)
    else:
        if y2 > y1:
            draw_line_y1(x1, y1, x2, y2)
        else:
            draw_line_y2(x1, y1, x2, y2)


# -----_____----- Functions End -----_____-----

n = 40
radius = 180.
cenx = 199.5
ceny = 199.5

for i in range(0, n + 1):
    theta = (2 * pi * i / n)

    x2 = cenx + radius * cos(theta)
    y2 = ceny + radius * sin(theta)

    if (i > 0):
        draw_line(x1, y1, x2, y2)

    x1 = x2
    y1 = y2

# Convert array to an image

arr_3d = np.array(image).reshape((HEIGHT, WIDTH, 3))

img = Image.fromarray(np.uint8(arr_3d[::-1])).convert('RGB')
img.save("py_Line_x.bmp")