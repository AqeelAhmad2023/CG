import math
import numpy as np
from PIL import Image

width = 400
height = 400
image_size = 3 * width * height

line_color = [1., 1, 1]
background_color = [0., 0., 0.]
gamma_correction = True
image = bytearray(image_size)

def set_pixel(x, y, r, g, b):
    index = 3 * (x + width * y)
    if x >= 0 and x < width and y >= 0 and y < height:
        if gamma_correction:
            image[index    ] = int(255. * math.sqrt(r))
            image[index + 1] = int(255. * math.sqrt(g))
            image[index + 2] = int(255. * math.sqrt(b))
        else:
            image[index    ] = int(255. * r)
            image[index + 1] = int(255. * g)
            image[index + 2] = int(255. * b)


def draw_line_x1(x1, y1, x2, y2):
    x, iy = int(x1), int(y1)
    m = (y2 - y1) / (x2 - x1)
    y = y1 + (math.floor(x1) + 0.5 - x1) * m
    while x < math.floor(x2):
        iy = int(y)
        ofac = y - (iy + 0.5) if y > iy + 0.5 else iy + 0.5 - y
        ffac = 1. - ofac
        r = ofac * background_color[0] + ffac * line_color[0]
        g = ofac * background_color[1] + ffac * line_color[1]
        b = ofac * background_color[2] + ffac * line_color[2]
        set_pixel(x, iy, r, g, b)
        if y > iy + 0.5:
            set_pixel(x, iy+1, ffac * background_color[0] + ofac * line_color[0], ffac * background_color[1] + ofac * line_color[1], ffac * background_color[2] + ofac * line_color[2])
        else:
            set_pixel(x, iy-1, ffac * background_color[0] + ofac * line_color[0], ffac * background_color[1] + ofac * line_color[1], ffac * background_color[2] + ofac * line_color[2])
        x += 1
        y += m


def draw_line_x2(x1, y1, x2, y2):
    xstep = 1
    m = (y2 - y1) / (x2 - x1)
    y = y1 + (int(x1) + 0.5 - x1) * m
    for x in range(int(x1), int(x2)-xstep, -xstep):
        iy = int(y)
        if y > iy + 0.5:
            ofac = y - (iy + 0.5)
            ffac = 1. - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(x, iy, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(x, iy+1, r, g, b)
        else:
            ofac = iy + 0.5 - y
            ffac = 1. - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(x, iy, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(x, iy-1, r, g, b)
        y -= m



def draw_line_y1(x1, y1, x2, y2):
    m = (x2 - x1) / (y2 - y1)
    x = x1 + (math.floor(y1) + 0.5 - y1) * m
    for y in range(math.floor(y1), math.floor(y2)):
        ix = int(math.floor(x))
        if x > ix + 0.5:
            ofac = x - (ix + 0.5)
            ffac = 1.0 - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(ix, y, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(ix + 1, y, r, g, b)
        else:
            ofac = ix + 0.5 - x
            ffac = 1.0 - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(ix, y, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(ix - 1, y, r, g, b)
        x += m


def draw_line_y2(x1, y1, x2, y2):
    m = (x2 - x1) / (y2 - y1)
    x = x1 + (math.floor(y1) + .5 - y1) * m
    for y in range(math.floor(y1), math.floor(y2), -1):
        ix = math.floor(x)
        if x > ix + .5:
            ofac = x - (ix + .5)
            ffac = 1. - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(ix, y, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(ix + 1, y, r, g, b)
        else:
            ofac = ix + .5 - x
            ffac = 1. - ofac
            r = ofac * background_color[0] + ffac * line_color[0]
            g = ofac * background_color[1] + ffac * line_color[1]
            b = ofac * background_color[2] + ffac * line_color[2]
            set_pixel(ix, y, r, g, b)
            r = ffac * background_color[0] + ofac * line_color[0]
            g = ffac * background_color[1] + ofac * line_color[1]
            b = ffac * background_color[2] + ofac * line_color[2]
            set_pixel(ix - 1, y, r, g, b)
        x -= m

def draw_line(x1, y1, x2, y2):
    if abs(x2 - x1) > abs(y2 - y1):
        if x2 > x1:
            draw_line_x1(x1, y1, x2, y2)
        else:
            draw_line_x2(x1, y1, x2, y2)
    else:
        if y2 > y1:
            draw_line_y1(x1, y1, x2, y2)
        else:
            draw_line_y2(x1, y1, x2, y2)

if __name__ == '__main__':
    n = 40

    radius = 180.0
    for j in range(n+1):
        x2 = 199.5 + radius * math.cos(2 * math.pi * j / n)
        y2 = 199.5 + radius * math.sin(2 * math.pi * j / n)
        if j > 0:
            draw_line(x1, y1, x2, y2)
        x1 = x2
        y1 = y2

# Convert array to an image

arr_3d = np.array(image).reshape((height, width, 3))

img = Image.fromarray(np.uint8(arr_3d[::-1])).convert('RGB')
if gamma_correction:
    img.save("py_antialiased_lines_gamma.bmp")
else:
    img.save("py_antialiased_lines_no_gamma.bmp")




