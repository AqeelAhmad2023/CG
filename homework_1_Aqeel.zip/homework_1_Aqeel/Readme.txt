Requirements:
import math
import numpy as np
from PIL import Image


Here I admit that I have taken most of the help from the book and lecture slides. Moroever, the hint like the equation triggered me to do it like this way.