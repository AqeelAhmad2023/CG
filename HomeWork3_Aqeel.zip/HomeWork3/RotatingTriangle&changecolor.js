// Vertex shader program
var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' +
  'uniform mat4 u_ModelMatrix;\n' +
  'void main() {\n' +
  '  gl_Position = u_ModelMatrix * a_Position;\n' +
  '}\n';

// Fragment shader program
var FSHADER_SOURCE =
  'precision mediump float;\n' +
  'uniform vec4 u_FragColor;\n' +  //declaring uniform fragcolor to take color from javascript
  'void main() {\n' +
  '  gl_FragColor = u_FragColor;\n' +
  '}\n';


function main() {
  // Retrieve <canvas> element
  var canvas = document.getElementById('webgl');

  // Get the rendering context for WebGL
  var gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }

  // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  // Write the positions of vertices to a vertex shader
  var n = initVertexBuffers(gl);
  if (n < 0) {
    console.log('Failed to set the positions of the vertices');
    return;
  }

  // Specify the color for clearing <canvas>
  gl.clearColor(0.0, 0.0, 0.0, 1.0);

  // Get storage location of u_ModelMatrix
  var u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
  if (!u_ModelMatrix) {
    console.log('Failed to get the storage location of u_ModelMatrix');
    return;
  }

  // Current rotation angle
  var currentRotationAngle = 90.0;
  // Model matrix
  var modelMatrix = new Matrix4();

  // Start drawing the object
  var make = function () {
    currentRotationAngle = animate_object(currentRotationAngle);  // this will update the current rotation angle
    draw_object(gl, n, currentRotationAngle, modelMatrix, u_ModelMatrix);   // Draw the triangle
    requestAnimationFrame(make, canvas); // Request that the browser calls make
  };
  make();
}

function initVertexBuffers(gl) {
  var vertices = new Float32Array([
    0, 0.5, -0.5, -0.5, 0.5, -0.5
  ]);
  var n_vertices= 3;   // The number of vertices

  // Create a buffer object
  var vertexBuffer = gl.createBuffer();
  if (!vertexBuffer) {
    console.log('Failed to create the buffer object');
    return -1;
  }

  // Bind the buffer object to target
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  // Write date into the buffer object
  gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

  // Assign the buffer object to a_Position variable
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return -1;
  }
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);

  // Enable the assignment to a_Position variable
  gl.enableVertexAttribArray(a_Position);

  return n_vertices;
}

function draw_object(gl, n_vertices, currentRotationAngle, modelMatrix, u_ModelMatrix) {

   // varies from 0 to 6
  radius = 6*currentRotationAngle / 360;
  difference=radius - Math.floor(radius);
  fac = 1 - (difference); 
  a=[0.0, 0.0, 1.0];
  bt=[0.6, 0.0, 0.6];
  c=[0.9, 0.0, 0.0];
  d=[0.6, 0.6, 0.0];
  e=[0.0, 0.8, 0.0];
  f=[0.0, 0.6, 0.6];
  gt=[0.0, 0.0, 1.0];
  h=[0.6, 0.0, 0.6];
  r = [a,bt,c,d,e,f,gt,h][Math.floor(radius)][0] * fac + [a,bt,c,d,e,f,gt,h][Math.floor(radius) + 1][0] * (1 - fac)
  g =[a,bt,c,d,e,f,gt,h][Math.floor(radius)][1] * fac + [a,bt,c,d,e,f,gt,h][Math.floor(radius) + 1][1] * (1 - fac)
  b =[a,bt,c,d,e,f,gt,h][Math.floor(radius)][2] * fac + [a,bt,c,d,e,f,gt,h][Math.floor(radius) + 1][2] * (1 - fac)

  
  if (!gl.getUniformLocation(gl.program, 'u_FragColor')) {
    console.log('Failed to get the storage location of u_FragColor');
    return;
  }
  gl.uniform4f(gl.getUniformLocation(gl.program, 'u_FragColor'), r, g, b, 1);


  
  // Pass the rotation matrix to the vertex shader
  gl.uniformMatrix4fv(u_ModelMatrix, false, modelMatrix.elements);

  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);

  // Draw the rectangle
  gl.drawArrays(gl.TRIANGLES, 0, n_vertices);
  //Set the rotation matrix
  modelMatrix.setRotate(currentRotationAngle, 0, 0, 1); // Rotation angle, rotation axis (0, 0, 1)
}
// Rotation angle (degrees/second)
var Rotation_ANGLE_STEP = 45.0;
var total_time =1000.0;

// Last time that this function was called
var g_last_time = Date.now();
function animate_object(angle) {
  // Calculate the elapsed time
  var now = Date.now();
  var elapsed = now - g_last_time;
  g_last_time = now;
  var next_Angle = angle + (Rotation_ANGLE_STEP * elapsed) / total_time;
  return next_Angle %= 360;
}
